const help = (prefix) => {
	return `
       
       OPÇÕES DO MENU
       
       
*${prefix}sticker* ou *${prefix}stiker*
Utilidade: converter imagem/gif/vídeo em adesivo
Uso: responder imagem/gif/video ou enviar imagem/gif/video com legenda\n

*${prefix}sticker nobg* ou *${prefix}stiker nobg*
Utilidade: converter imagem em adesivo removendo o fundo
Uso: responder imagem ou enviar imagem com legenda/n

*${prefix}toimg*
Utilidade: converter adesivo em imagem

*${prefix}tsticker* ou *${prefix}tstiker*
Utilidade: converter texto em adesivo

*${prefix}gtts*
Utilidade: converter texto em fala/áudio

*${prefix}ocr*
Utilidade: pegar o texto da foto e lhe enviar`

}

exports.help = help
S





